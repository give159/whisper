import os
from playwright.sync_api import sync_playwright
MERMAID=open('/tmp/mmd2/node_modules/mermaid/dist/mermaid.min.js',encoding='utf-8').read()
FIGS={
"w01-overall": """flowchart TD
  U["利用者（ブラウザ）"] --> P["画面（index.html・app.js・lib.js）"]
  P -- "音声ファイル（multipart）" --> API["文字起こしの窓口（API）"]
  API -- "JSON（text）" --> P
  P --> OUT["結果の欄・テキストで保存"]
  M["練習：模倣サーバー（APIキー不要）"] -. "同じ形で答える" .-> API""",
"w02-sequence": """sequenceDiagram
  participant U as 利用者
  participant A as app.js
  participant L as lib.js
  participant S as 窓口（API）
  U->>A: ファイルを選ぶ
  A->>L: checkFile（大きさ・形式）
  L-->>A: OK または 理由
  U->>A: 文字起こし
  A->>S: POST（file、model、Bearer）
  S-->>A: 200 と text
  A-->>U: 結果を表示""",
"w03-page-state": """stateDiagram-v2
  [*] --> 待機
  待機 --> 準備完了 : 音声を選ぶ（確認OK）
  待機 --> 待機 : 確認NG（理由を表示）
  準備完了 --> 送信中 : 文字起こし
  送信中 --> 完了 : 200
  送信中 --> エラー : 失敗（401・429など）
  エラー --> 準備完了 : 直して再度
  完了 --> 準備完了 : 別のファイル""",
"w04-file-check": """flowchart TD
  F["選んだファイル"] --> Q1{"空？"}
  Q1 -- はい --> N1["送らない：空のファイル"]
  Q1 -- いいえ --> Q2{"25 MB 以下？"}
  Q2 -- いいえ --> N2["送らない：大きすぎる"]
  Q2 -- はい --> Q3{"音声の形式？"}
  Q3 -- いいえ --> N3["送らない：音声ではない"]
  Q3 -- はい --> OK["送ってよい"]""",
"w05-errors": """flowchart LR
  E["失敗"] --> C1["接続できない"]
  E --> C2["401・403"]
  E --> C3["429"]
  E --> C4["5xx"]
  C1 --> R1["再試行する"]
  C3 --> R1
  C4 --> R1
  C2 --> R2["再試行しない（キーを直す）"]""",
"w06-tests": """flowchart TD
  T1["計算の試験（lib.test.js）13件中7件"] --> T2["サーバーの試験（server.test.js）6件"]
  T2 --> T3["画面の試験（e2e_web.py）7件"]
  T3 --> T4["本物のAPI（確認は最後に少量）"]""",
"w07-learning-map": """flowchart LR
  A["1 考える（前提・Why）"] --> B["2 準備（環境）"]
  B --> C["3 作る（画面・計算・送信）"]
  C --> D["4 試す（模倣・試験）"]
  D --> E["5 直す（デバッグ・改修）"]
  E --> F["6 本物へ（少量・確認）"]""",
"w08-size-math": """flowchart LR
  A["1分の音声（16kHz・モノラル・16bit）"] --> B["約1.9 MB"]
  B --> C["25 MB ÷ 1.9 MB ≒ 13分"]
  C --> D["長い音声は分ける、または圧縮形式で送る"]""",
}
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1100,'height':800}, device_scale_factor=2)
    pg.set_content("<html><body style='margin:0;background:#fff;font-family:sans-serif'><div id='out'></div></body></html>")
    pg.add_script_tag(content=MERMAID)
    for name,code in FIGS.items():
        svg=pg.evaluate("""async ([id,c])=>{ mermaid.initialize({startOnLoad:false, theme:'neutral', securityLevel:'loose'});
            const r=await mermaid.render(id,c); return r.svg; }""", [name.replace('-','_'), code])
        pg.evaluate("(s)=>{document.getElementById('out').innerHTML=s}", svg)
        pg.locator('#out svg').first.screenshot(path=f"{name}.png"); print(name, os.path.getsize(f"{name}.png"))
    b.close()
