/* config.example.js — 設定の雛形。
 * 使い方：このファイルを config.js という名前でコピーし、値を入れる。
 * 注意：config.js にはAPIキーを書くため、共有しない・Git に入れない（.gitignore で除外）。
 * 練習のときは、endpoint を http://localhost:8790 にする（APIキーは不要）。 */
window.WHISPER_CONFIG = Object.freeze({
  endpoint: "http://localhost:8790",      // 練習：模倣サーバー。本番：公式の接続先（https://api.openai.com）
  apiKey: "",                             // 練習：空でよい（mock は test-key を受け付ける）
  model: "whisper-1",                     // 使うモデル名。利用の前に公式ドキュメントで確認すること
  maxFileMB: 25,                          // 公式が案内する1ファイルの上限（MB）
  timeoutMs: 120000,                      // 応答の上限（ミリ秒）
});
