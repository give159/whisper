#!/usr/bin/env bash
# ============================================================================
# azure_mock_check.sh — Azure Speech 風の模倣サーバー（mock-server.js）の動作を、手順どおりに確かめる
# 使い方（プロジェクトのフォルダで）：
#   bash scripts/azure_mock_check.sh            # 基本の4つの確認
#   bash scripts/azure_mock_check.sh retry      # 再試行の確認（2回目を 429 にする）
# 課金は発生しない。本物の Azure には接続しない。
# ============================================================================
set -u
cd "$(dirname "$0")/.."
PORT=8787
URL="http://localhost:${PORT}/speechtotext/transcriptions:transcribe?api-version=2024-11-15"
KEY="mock-key"
MODE="${1:-basic}"
PASS=0; FAIL=0

check() {  # check "説明" 期待コード 実際コード
  if [ "$3" = "$2" ]; then echo "[合] $1（HTTP $3）"; PASS=$((PASS+1));
  else echo "[否] $1：期待 HTTP $2、実際 HTTP $3"; FAIL=$((FAIL+1)); fi
}

command -v node >/dev/null || { echo "node が見つかりません（Node.js 18 以上を入れてください）"; exit 2; }
[ -f test/sample-2min.wav ] || { mkdir -p test; node make-test-wav.js >/dev/null; }
AUDIO="test/sample-2min.wav"

# モックを起動（再試行の確認のときだけ FAIL_EVERY=2）
if [ "$MODE" = "retry" ]; then export FAIL_EVERY=2; fi
PORT=$PORT node mock-server.js > /tmp/azure-mock.log 2>&1 &
MOCK_PID=$!
for i in $(seq 1 20); do ss -ltn | grep -q ":${PORT} " && break; sleep 0.3; done
echo "モックを起動しました（PID ${MOCK_PID}、ポート ${PORT}、モード：${MODE}）"

if [ "$MODE" = "retry" ]; then
  c1=$(curl -s -o /dev/null -w "%{http_code}" -X POST "$URL" -H "Ocp-Apim-Subscription-Key: $KEY" -F "audio=@$AUDIO")
  c2=$(curl -s -o /dev/null -w "%{http_code}" -X POST "$URL" -H "Ocp-Apim-Subscription-Key: $KEY" -F "audio=@$AUDIO")
  check "1回目は成功する" 200 "$c1"
  check "2回目は 429（利用上限）になる（FAIL_EVERY=2）" 429 "$c2"
else
  c=$(curl -s -o /tmp/azure-ok.json -w "%{http_code}" -X POST "$URL" -H "Ocp-Apim-Subscription-Key: $KEY" \
      -F "audio=@$AUDIO;filename=segment.wav;type=audio/wav" \
      -F 'definition={"locales":["ja-JP"],"profanityFilterMode":"None"}')
  check "正しいキーで、認識結果が返る" 200 "$c"
  grep -q "combinedPhrases" /tmp/azure-ok.json && echo "    応答に combinedPhrases がある" || { echo "[否] 応答に combinedPhrases がない"; FAIL=$((FAIL+1)); }
  c=$(curl -s -o /dev/null -w "%{http_code}" -X POST "$URL" -H "Ocp-Apim-Subscription-Key: wrong" -F "audio=@$AUDIO")
  check "誤ったキーは 401" 401 "$c"
  c=$(curl -s -o /dev/null -w "%{http_code}" -X POST "$URL" -F "audio=@$AUDIO")
  check "キーなしは 401" 401 "$c"
  c=$(curl -s -o /dev/null -w "%{http_code}" -X POST "http://localhost:${PORT}/wrong-path" -H "Ocp-Apim-Subscription-Key: $KEY")
  check "経路の誤りは 404" 404 "$c"
fi

kill $MOCK_PID 2>/dev/null; wait $MOCK_PID 2>/dev/null
echo "結果：合格 ${PASS}、不合格 ${FAIL}"
[ "$FAIL" -eq 0 ]
